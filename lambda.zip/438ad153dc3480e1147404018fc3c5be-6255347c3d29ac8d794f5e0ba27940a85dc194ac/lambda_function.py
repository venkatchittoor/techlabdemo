import os
import json
import cv2
import logging
import boto3

s3 = boto3.client('s3')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    
    print("Starting handler")
    
    # get object metadata from event
    input_bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_key = event['Records']['s3']['object']['key']
    output_bucket_name = os.environment['OUTPUT_BUCKET_NAME']
    output_file_key = file_key.replace('.jpg', '.png')
    
    print("Input bucket: ", input_bucket_name)
    print("Output bucket: ", output_bucket_name)